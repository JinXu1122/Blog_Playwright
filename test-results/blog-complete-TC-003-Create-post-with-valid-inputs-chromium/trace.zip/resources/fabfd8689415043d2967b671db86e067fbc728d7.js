(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__02nfq85._.css","static/chunks/node_modules_next_0ur6.u-._.js","static/chunks/src_components_SearchBar_tsx_03pda~-._.js"],
    source: "dynamic"
});
